
package com.mycompany.perez_nicolas_p1_322;

public enum Compuesto {

    SOFT,
    MEDIUM,
    HARD,
    INTERMEDIO,
    WET;
    
}
