
package com.mycompany.perez_nicolas_p1_322;


public class Ala extends Pieza implements Ajustable{
    
    private static final int MAX_CARGA_AERODINAMICA = 10;
    private static final int MIN_CARGA_AERODINAMICA = 1;
    private int cargaAerodinamica;

    public Ala(String nombre, Ubicacion ubicacion, CondicionClimatica condicionFavorable,int cargaAerodinamica) {
        super(nombre, ubicacion, condicionFavorable);
        validarCargaAerodinamica(cargaAerodinamica);
        this.cargaAerodinamica = cargaAerodinamica;
    }
    
    private void validarCargaAerodinamica(int c){
        if(c < MIN_CARGA_AERODINAMICA || c > MAX_CARGA_AERODINAMICA){
            throw new IllegalArgumentException("Fuera de rango!");
        }
    }
    
    @Override
    protected String getClase(){
        return "Ala";
    }
    
    @Override
    public String toString(){
        return this.getClase() + " " + super.toString() + " Carga Aerodinamica: " + cargaAerodinamica;
    }
    
    @Override
    public void ajustar(){
        System.out.println("Ajustando ala...");
    }
    
    
    
}
