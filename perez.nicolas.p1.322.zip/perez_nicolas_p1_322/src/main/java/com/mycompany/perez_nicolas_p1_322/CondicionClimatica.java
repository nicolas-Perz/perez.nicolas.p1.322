
package com.mycompany.perez_nicolas_p1_322;

public enum CondicionClimatica {
    
    SECO,
    LLUVIA,
    MIXTO;
    
}
