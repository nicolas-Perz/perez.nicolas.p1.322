
package com.mycompany.perez_nicolas_p1_322;

public class Perez_nicolas_p1_322 {

    public static void main(String[] args) {
        
        Box b1 = new Box();
        
        Ala ala1 = new Ala("Ala1",Ubicacion.ESTACION_AEREO,CondicionClimatica.MIXTO,9);
        Motor motor1 = new Motor("Motor1",Ubicacion.ESTACION_MOTOR,CondicionClimatica.SECO,1500);
        Neumatico neum1 = new Neumatico("Neum1",Ubicacion.CARRO_NEUMATICOS,CondicionClimatica.LLUVIA,Compuesto.WET);
        
        Ala ala2 = new Ala("Ala2",Ubicacion.ESTACION_AEREO,CondicionClimatica.SECO,7);
        Motor motor2 = new Motor("Motor2",Ubicacion.ESTACION_MOTOR,CondicionClimatica.MIXTO,2500);
        Neumatico neum2 = new Neumatico("Neum2",Ubicacion.CARRO_NEUMATICOS,CondicionClimatica.SECO,Compuesto.SOFT);
        
        Ala ala3 = new Ala("Ala3",Ubicacion.ESTACION_AEREO,CondicionClimatica.LLUVIA,10);
        Motor motor3 = new Motor("Motor3",Ubicacion.ESTACION_MOTOR,CondicionClimatica.SECO,1000);
        Neumatico neum3 = new Neumatico("Neum3",Ubicacion.CARRO_NEUMATICOS,CondicionClimatica.SECO,Compuesto.SOFT);
        
        b1.agregarPieza(ala1);
        b1.agregarPieza(motor1);
        b1.agregarPieza(neum1);
        b1.agregarPieza(ala2);
        b1.agregarPieza(motor2);
        b1.agregarPieza(neum2);
        b1.agregarPieza(ala3);
        b1.agregarPieza(motor3);
        b1.agregarPieza(neum3);
        
        System.out.println("-------------------AJUSTAR PIEZAS------------------------");
        b1.ajustarPiezas();
        
        System.out.println("--------------------MOSTRAR PIEZAS--------------------------");
        b1.mostrarPiezas();
        
        System.out.println("-------------------BUSCAR PIEZAS-------------------------------");
        System.out.println(b1.buscarPiezasPorCondicion(CondicionClimatica.SECO));
        
    }
}
