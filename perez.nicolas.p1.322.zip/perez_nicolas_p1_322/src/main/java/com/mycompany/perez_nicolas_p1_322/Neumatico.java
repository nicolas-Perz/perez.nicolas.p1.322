
package com.mycompany.perez_nicolas_p1_322;


public class Neumatico extends Pieza{
    
    private Compuesto compuesto;

    public Neumatico(String nombre, Ubicacion ubicacion, CondicionClimatica condicionFavorable,Compuesto compuesto) {
        super(nombre, ubicacion, condicionFavorable);
        this.compuesto = compuesto;
    }
    
    @Override
    protected String getClase(){
        return "Neumatico";
    }
    
    @Override
    public String toString(){
        return this.getClase() + " "  + super.toString() + " Compuesto: " + compuesto;
    }
    
}
