
package com.mycompany.perez_nicolas_p1_322;

public abstract class Pieza {
    
    private String nombre;
    private Ubicacion ubicacion;
    private CondicionClimatica condicionFavorable;

    public Pieza(String nombre, Ubicacion ubicacion, CondicionClimatica condicionFavorable) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.condicionFavorable = condicionFavorable;
    }
    
    public CondicionClimatica getCondicionFavorable(){
        return condicionFavorable;
    }
    
    protected abstract String getClase();
    
    @Override
    public String toString(){
        return "Nombre: " + nombre + " Ubicacion: " + ubicacion + " Condicion Favorable: " + condicionFavorable;
    }
    
}
