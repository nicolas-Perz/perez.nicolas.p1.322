
package com.mycompany.perez_nicolas_p1_322;


public enum Ubicacion {
    
    ESTACION_MOTOR,
    ESTACION_AEREO,
    CARRO_NEUMATICOS;
    
}
