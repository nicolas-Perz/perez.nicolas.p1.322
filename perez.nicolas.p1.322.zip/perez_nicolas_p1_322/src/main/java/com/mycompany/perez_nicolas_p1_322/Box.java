
package com.mycompany.perez_nicolas_p1_322;

import java.util.ArrayList;

public class Box {
    
    private ArrayList<Pieza> listaPiezas;
    
    public Box(){
        listaPiezas = new ArrayList<>();
    };
    
    // AGREGAR PIEZAS ------------------------------------------------------------------------
    
    public void agregarPieza(Pieza p){
        try{
            validarPiezaNula(p);
            validarPiezaRepetida(p);
            listaPiezas.add(p);
        }catch(DuplicatePieceException ex){
            System.out.println(ex.getMessage());
        }
    }
    
    private void validarPiezaNula(Pieza p){
        if(p == null){
            throw new IllegalArgumentException();
        }
    }
    private void validarPiezaRepetida(Pieza p) throws DuplicatePieceException{
        if(buscarPiezaRepetida(p)){
            throw new DuplicatePieceException("La pieza ya está ingresada!");
        }
    }
    private boolean buscarPiezaRepetida(Pieza p){
        boolean toReturn = false;
        int x = 0;
        
        while(x < listaPiezas.size() && toReturn == false){
            Pieza piezaActual = listaPiezas.get(x++);
            if(p.equals(piezaActual)){
                toReturn = true;
            }
        }
        return toReturn;
    }
    
    // -------------------------------------------------------------------------------------------
    
    public void mostrarPiezas(){
        System.out.println("Piezas!");
        for(Pieza p:listaPiezas){
            System.out.println(p);
        }
    }
    
    public void ajustarPiezas(){
        for(Pieza p:listaPiezas){
            if(p instanceof Ajustable){
                Ajustable a = (Ajustable) p;
                a.ajustar();
            }else{
                System.out.println(p.getClase() + " No puede ser ajustado!");
            }
        }
    }
    
    public String buscarPiezasPorCondicion(CondicionClimatica c){
        StringBuilder toReturn = new StringBuilder();
        
        for(Pieza p:listaPiezas){
            if(p.getCondicionFavorable() == c){
                toReturn.append(p + "\n");
            }
        }
        
        return toReturn.toString();
    }
    
}
