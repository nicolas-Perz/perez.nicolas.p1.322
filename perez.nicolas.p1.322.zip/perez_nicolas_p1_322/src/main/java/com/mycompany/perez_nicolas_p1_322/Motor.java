
package com.mycompany.perez_nicolas_p1_322;


public class Motor extends Pieza implements Ajustable{
    
    private int max_potencia;

    public Motor(String nombre, Ubicacion ubicacion, CondicionClimatica condicionFavorable,int max_potencia) {
        super(nombre, ubicacion, condicionFavorable);
        this.max_potencia = max_potencia;
    }
    
    @Override
    protected String getClase(){
        return "Motor";
    }
    
    @Override
    public String toString(){
        return this.getClase() + " "  + super.toString() + " Maxima Potencia: " + max_potencia;
    }
    
    @Override
    public void ajustar(){
        System.out.println("Ajustando motor...");
    }
    
}
