
package com.mycompany.perez_nicolas_p1_322;


public interface Ajustable {
    
    public abstract void ajustar();
    
    
    
}
