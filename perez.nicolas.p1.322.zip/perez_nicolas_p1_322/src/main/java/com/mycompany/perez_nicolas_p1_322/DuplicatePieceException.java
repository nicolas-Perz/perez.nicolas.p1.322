
package com.mycompany.perez_nicolas_p1_322;


public class DuplicatePieceException extends Exception{
    
    private static final String MENSAJE = "Piece Duplicate";
    
    public DuplicatePieceException(){
        this(MENSAJE);
    }
    public DuplicatePieceException(String msj){
        super(msj);
    }
    
}
